
	<div class="subnavbar hidden-xs">
  <div class="subnavbar-inner">
    <div class="container">
      <ul class="mainnav">
        <li class="active"><a href="<?php echo base_url();?>travelplans/planschedul"><i class="fa fa-dashboard"></i><span>Dashboard</span> </a> </li>
        <li class="active"><a href="<?php echo base_url();?>timelinepost/timeline"><i class="icon_clock_alt"></i><span>Timeline</span> </a> </li>
        <li class="active"><a href="<?php echo base_url();?>admin_products/add"><i class="icon_folder-add_alt"></i><span>Add Product</span> </a></li>
        <li class="active"><a href="<?php echo base_url();?>admin_products"><i class="fa fa-flask "></i><span>My Products</span></a></li>
        <li class="active"><a href="inbox.html"><i class="icon_mail_alt"></i><span> My Inbox</span> </a> </li>
		<li class="active"><a href="inquiry.html"><i class="icon_mail_alt"></i> <span>My Enquiry</span> </a> </li>
        <li class="active"><a href="<?php echo base_url();?>user/profile"><i class="fa fa-user"></i><span>My Profile</span> </a> </li>
		<li class="active"><a href="<?php echo base_url();?>user/ChangePassword"><i class="fa fa-unlock"></i><span>Change Password</span> </a> </li>
		 
        
      </ul>
    </div>
    <!-- /container --> 
  </div>
  <!-- /subnavbar-inner --> 
</div>