<?php
$route['default_controller'] = "adminzone";

/* ********************************  End  */
