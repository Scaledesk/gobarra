<?php $this->load->view('admin/popup_header'); ?>
	<div class="heading">
    <h1 >   <?php echo $pageresult->page_name; ?></h1>
  </div>
	<table width="100%"  border="0" cellspacing="0" cellpadding="0">
		
		<tr>
			<td style="padding:5px;"><?php echo $pageresult->page_desc;?></td>
		</tr>
	</table>
	
</body>
</html>