<?php
$route['pages/refer_to_friends/(:num)']       = 'pages/refer_to_friends/$1';
$route['pages/subscribe_newsletter']          = 'pages/subscribe_newsletter/$1';
$route['pages/(:any)']                        = 'pages/index/$1';
$route['pages/contactus']                     = 'pages/contactus/$1';
$route['pages/sitemap']                       = 'pages/sitemap/$1';
$route['pages/faq']                           = 'pages/faq/$1';
$route['pages/refer_to_friends']              = 'pages/refer_to_friends';
$route['pages/join_newsletter']               = 'pages/join_newsletter';
