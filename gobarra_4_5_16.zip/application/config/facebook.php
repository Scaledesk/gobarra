<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
   // $config['appId']   = '659065637530173';
    //$config['secret']  = 'a35ef95883013454cd5a3311cef8abf5';
     $config['appId']   = '1050957461621407';
     $config['secret']  = '7ed7b89a85d0c68f07eacbea5dd0ff5f';
?>